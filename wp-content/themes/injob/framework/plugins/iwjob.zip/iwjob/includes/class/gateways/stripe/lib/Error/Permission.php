<?php

namespace Stripe\Error;

class Permission extends Base
{
}
