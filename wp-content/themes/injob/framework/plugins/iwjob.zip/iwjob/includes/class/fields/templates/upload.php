<script id="tmpl-iwjmb-upload-area" type="text/html">
  <div class="iwjmb-upload-inside">
	<h3>{{{ i18niwjmbMedia.uploadInstructions }}}</h3>
	<p>{{{ i18niwjmbMedia.or }}}</p>
	<p><a href="#" class="iwjmb-browse-button button button-hero" id="{{{ _.uniqueId( 'iwjmb-upload-browser-') }}}">{{{ i18niwjmbMedia.select }}}</a></p>
  </div>
</script>
